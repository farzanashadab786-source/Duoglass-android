package dev.aqdas.duoglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DuoGlassApp() }
    }
}

@Composable
private fun DuoGlassApp() {
    var angle by remember { mutableFloatStateOf(90f) }
    var frost by remember { mutableFloatStateOf(0.72f) }
    var darken by remember { mutableFloatStateOf(0.22f) }
    val animatedAngle by animateFloatAsState(
        targetValue = angle,
        animationSpec = tween(260, easing = FastOutSlowInEasing),
        label = "hinge"
    )

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF090B0D),
            surface = Color(0xFF15191D),
            primary = Color(0xFFD7C6A0),
            onBackground = Color(0xFFECE9E2),
            onSurface = Color(0xFFECE9E2)
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFF090B0D))
                .padding(horizontal = 22.dp, vertical = 26.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text("DUOGLASS", fontSize = 13.sp, letterSpacing = 4.sp,
                color = Color(0xFFD7C6A0), fontWeight = FontWeight.Bold)
            Text("A softer way to fold.", fontSize = 29.sp,
                color = Color(0xFFECE9E2), fontWeight = FontWeight.SemiBold)
            Text("A local folding-effect playground. No screen capture, accessibility service, or network access.",
                fontSize = 13.sp, color = Color(0xFF9CA3A8), lineHeight = 19.sp)

            Box(
                modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF171C20)),
                contentAlignment = Alignment.Center
            ) {
                FoldPreview(animatedAngle, frost, darken, Modifier.fillMaxSize())
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    Text("LIVE PREVIEW", color = Color.White.copy(alpha = .72f),
                        fontSize = 10.sp, letterSpacing = 2.sp)
                    Text("${angle.toInt()}°", color = Color.White,
                        fontSize = 27.sp, fontWeight = FontWeight.Medium)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("HINGE ANGLE", color = Color(0xFFECE9E2), fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                    Text("${angle.toInt()}°", color = Color(0xFFD7C6A0), fontSize = 12.sp)
                }
                Slider(value = angle, onValueChange = { angle = it }, valueRange = 0f..180f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("CLOSED", color = Color.Gray, fontSize = 9.sp)
                    Text("HALF OPEN", color = Color.Gray, fontSize = 9.sp)
                    Text("FLAT", color = Color.Gray, fontSize = 9.sp)
                }
            }
            ControlSlider("FROST", frost, { frost = it })
            ControlSlider("DARKENING", darken, { darken = it })
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { angle = 0f }, modifier = Modifier.weight(1f)) { Text("CLOSED") }
                OutlinedButton(onClick = { angle = 90f }, modifier = Modifier.weight(1f)) { Text("HALF") }
                Button(onClick = { angle = 180f }, modifier = Modifier.weight(1f)) { Text("OPEN") }
            }
            Text("DUOGLASS  •  PROTOTYPE 0.1.0", color = Color(0xFF697177),
                fontSize = 9.sp, letterSpacing = 1.4.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun ControlSlider(label: String, value: Float, onValue: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFECE9E2), fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
            Text("${(value * 100).toInt()}%", color = Color(0xFFD7C6A0), fontSize = 11.sp)
        }
        Slider(value = value, onValueChange = onValue, valueRange = 0f..1f)
    }
}

@Composable
private fun FoldPreview(angle: Float, frost: Float, darken: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(brush = Brush.linearGradient(
            listOf(Color(0xFF35464A), Color(0xFF18272D), Color(0xFF6B665B)),
            start = Offset(0f, 0f), end = Offset(w, h)
        ))
        // Decorative background shapes make the preview visibly respond without reading the screen.
        drawCircle(Color(0xFFB6A27B).copy(alpha = .24f), radius = w * .34f,
            center = Offset(w * .22f, h * .26f))
        drawCircle(Color(0xFF8FA9A6).copy(alpha = .22f), radius = w * .30f,
            center = Offset(w * .78f, h * .72f))
        val progress = angle / 180f
        val split = w * (.5f + (progress - .5f) * .10f)
        val panelShade = darken * (1f - abs(progress - .5f) * 1.3f).coerceIn(0f, 1f)
        // Frosted panel approximation: translucent wash + soft highlights, entirely synthetic.
        drawRect(Color.White.copy(alpha = frost * .20f), Offset(0f, 0f), Size(split, h))
        drawRect(Color.White.copy(alpha = frost * .12f), Offset(split, 0f), Size(w - split, h))
        drawRect(Color.Black.copy(alpha = panelShade), Offset(0f, 0f), Size(w, h))
        drawRect(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, Color.White.copy(alpha = .22f), Color.Transparent),
                startX = split - 26f, endX = split + 26f
            ),
            topLeft = Offset(split - 26f, 0f), size = Size(52f, h)
        )
        drawLine(Color.White.copy(alpha = .34f), Offset(split, 0f),
            Offset(split, h), strokeWidth = 1.5f)
        val bend = (1f - abs(progress - .5f) * 2f).coerceIn(0f, 1f)
        drawRect(Color.Black.copy(alpha = bend * .08f), Offset(0f, 0f), Size(w, h))
    }
}
