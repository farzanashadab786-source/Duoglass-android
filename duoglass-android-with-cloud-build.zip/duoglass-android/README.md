# DuoGlass

A privacy-first Android folding-effect playground.

## Current prototype

- Simulated hinge angle (0–180°)
- Adjustable frost and darkening
- Synthetic preview rendered locally with Compose Canvas
- No accessibility service
- No screen capture
- No Shizuku or ADB integration
- No network permission
- No analytics or tracking SDKs

## Build

Open this project in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**.

The generated debug APK is under `app/build/outputs/apk/debug/`.

## Privacy design

The preview is generated from shapes and gradients drawn by the app. It does not read, capture, or inspect other apps or the device screen. The manifest intentionally declares no permissions.

## Scope and limitations

This is an early prototype, not a system-wide overlay and not a true foldable hinge integration. It runs on ordinary Android phones and simulates the fold interaction inside the app. Live wallpaper support and refined AGSL rendering are planned, but are not implemented in this initial build.

## License

MIT. See `LICENSE`.
